# CHANGES TO tabulizerjars 1.0.1

* Release tabula-java 1.0.1

# CHANGES TO tabulizerjars 1.0.0

* Release tabula-java 1.0.0 (uses PDFBox 2)

# CHANGES TO tabulizerjars 0.9.2

* Release tabula-java 0.9.2

# CHANGES TO tabulizerjars 0.9.1

* Release tabula-java 0.9.1

# CHANGES TO tabulizerjars 0.9.0

* Release tabula-java 0.9.0

# CHANGES TO tabulizerjars 0.8.0

* Align version numbering of the package to tabula-java release numbers.
* Release tabula-java 0.8.0

# CHANGES TO tabulizerjars 0.1.2

* Enabled java headless mode in `.onLoad()`.
* Add copyright acknowledgement for tabulizer to DESCRIPTION.

# CHANGES TO tabulizerjars 0.1.1

* Initial release, moving jars from tabulizer to tabulizerjars.
