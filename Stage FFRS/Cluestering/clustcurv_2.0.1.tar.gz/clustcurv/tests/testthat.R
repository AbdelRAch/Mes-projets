library(testthat)
library(clustcurv)

testthat::test_check("clustcurv")
